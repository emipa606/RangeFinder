## RangeFinder Mod 
Show weapon ranges with the press of a buttton

Constantly checking the shooting range of your colonists? Range Finder makes it easy.

Just select one or more colonists and press the hotkey (Ctrl by default). When you quickly press the key twice the range will be shown until you press the key later again.

---

##### License

Free. As in free beer. Copy, learn and be respectful.

---

##### Contact

Andreas Pardeike  
Email: andreas@pardeike.net  
Steam: pardeike  
Twitter: @pardeike
